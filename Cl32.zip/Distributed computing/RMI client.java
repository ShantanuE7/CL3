import java.rmi.Naming;

public class StringConcatenationClient {

    public static void main(String[] args) {
        try {
            // Connect to the remote object using RMI registry
            StringConcatenation concatService = (StringConcatenation) Naming.lookup("rmi://localhost/StringConcatenationService");

            // Strings to concatenate
            String str1 = "Hello, ";
            String str2 = "World!";

            // Call the remote method to concatenate the strings
            String result = concatService.concatenateStrings(str1, str2);

            // Print the result
            System.out.println("Concatenated Result: " + result);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
